// Book flight logic
