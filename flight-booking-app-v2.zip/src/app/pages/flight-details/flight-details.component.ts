// Flight details logic
